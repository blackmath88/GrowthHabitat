import { Routes, Route } from "react-router-dom";
import { AppShell } from "./components/Shell";
import CommandCenter from "./pages/CommandCenter";
import { StubPage } from "./pages/StubPage";

const SEED_HYPOTHESIS =
  "AI workforce adoption inside governance-aware organizations is where my translator, activator, and structured creativity strengths compound fastest over the next 3 years.";

export default function App() {
  return (
    <AppShell
      ownerLabel="Achim's lab"
      hypothesis={SEED_HYPOTHESIS}
      hypothesisMeta="v1 · 5 conversations"
    >
      <Routes>
        <Route path="/" element={<CommandCenter />} />
        <Route
          path="/profile"
          element={
            <StubPage
              num="01"
              title="Profile"
              subtitle="Capture what you know about yourself before testing the market."
            />
          }
        />
        <Route
          path="/directions"
          element={
            <StubPage
              num="02"
              title="Directions"
              subtitle="Compare possible career paths before committing to one."
            />
          }
        />
        <Route
          path="/conversations"
          element={
            <StubPage
              num="03"
              title="Conversations"
              subtitle="Use real conversations to test where your value is recognized."
            />
          }
        />
        <Route
          path="/opportunities"
          element={
            <StubPage
              num="04"
              title="Opportunities"
              subtitle="Decide whether a role, company, or project deserves attention."
            />
          }
        />
        <Route
          path="/patterns"
          element={
            <StubPage
              num="05"
              title="Patterns"
              subtitle="Review the evidence and decide what to test next."
            />
          }
        />
      </Routes>
    </AppShell>
  );
}
