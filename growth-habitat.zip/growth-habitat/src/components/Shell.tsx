import type { ReactNode } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { Eyebrow } from "./Primitives";

// ---------- Navigation definition ----------
type NavEntry =
  | { to: string; label: string; glyph: string; num?: undefined }
  | { to: string; label: string; num: string; glyph?: undefined };

export const NAV: NavEntry[] = [
  { to: "/", label: "Command Center", glyph: "◇" },
  { to: "/profile", label: "Profile", num: "01" },
  { to: "/directions", label: "Directions", num: "02" },
  { to: "/conversations", label: "Conversations", num: "03" },
  { to: "/opportunities", label: "Opportunities", num: "04" },
  { to: "/patterns", label: "Patterns", num: "05" },
];

// ---------- Sidebar ----------
function Sidebar({
  ownerLabel,
  hypothesis,
  hypothesisMeta,
}: {
  ownerLabel: string;
  hypothesis: string;
  hypothesisMeta?: string;
}) {
  return (
    <aside
      style={{
        position: "fixed",
        inset: "0 auto 0 0",
        width: "var(--gh-sidebar-w)",
        background: "var(--gh-canvas-deep)",
        borderRight: "1px solid var(--gh-line)",
        display: "flex",
        flexDirection: "column",
        zIndex: 30,
      }}
    >
      {/* Brand */}
      <div
        style={{
          padding: "22px 22px 20px",
          borderBottom: "1px solid var(--gh-line-soft)",
          display: "flex",
          gap: 12,
          alignItems: "center",
        }}
      >
        <div
          style={{
            width: 32,
            height: 32,
            borderRadius: 6,
            background: "var(--gh-canvas)",
            border: "1px solid var(--gh-line)",
            display: "grid",
            placeItems: "center",
          }}
        >
          <svg width="20" height="20" viewBox="0 0 64 64" fill="none">
            <g
              stroke="var(--gh-espresso)"
              strokeWidth="3"
              strokeLinecap="round"
            >
              <path d="M 32 50 L 32 18" />
              <path d="M 32 28 C 26 26 22 22 21 16 C 27 16 31 20 32 26" />
              <path d="M 32 36 C 38 34 42 30 43 24 C 37 24 33 28 32 34" />
              <path d="M 32 44 C 26 42 22 38 21 32 C 27 32 31 36 32 42" />
            </g>
          </svg>
        </div>
        <div>
          <div
            style={{
              fontFamily: "var(--gh-serif)",
              fontVariationSettings: "'opsz' 14, 'SOFT' 0, 'wght' 500",
              fontSize: 16,
              color: "var(--gh-ink)",
              letterSpacing: "-0.01em",
              lineHeight: 1.1,
            }}
          >
            Growth Habitat
          </div>
          <div className="gh-eyebrow" style={{ marginTop: 6 }}>
            {ownerLabel}
          </div>
        </div>
      </div>

      {/* Command Center (top) */}
      <div style={{ padding: "12px 10px 8px" }}>
        <NavRow entry={NAV[0]} />
      </div>

      {/* Discovery group */}
      <div style={{ padding: "8px 18px 4px" }}>
        <Eyebrow>Discovery</Eyebrow>
      </div>
      <div style={{ padding: "4px 10px" }}>
        {NAV.slice(1).map((it) => (
          <NavRow key={it.to} entry={it} />
        ))}
      </div>

      {/* Hypothesis footer */}
      <div
        style={{
          marginTop: "auto",
          padding: "16px 18px 22px",
          borderTop: "1px solid var(--gh-line-soft)",
        }}
      >
        <Eyebrow>Current hypothesis</Eyebrow>
        <div
          style={{
            marginTop: 10,
            fontFamily: "var(--gh-serif)",
            fontVariationSettings: "'opsz' 14, 'SOFT' 0, 'wght' 500",
            fontSize: 13,
            color: "var(--gh-ink)",
            lineHeight: 1.45,
          }}
        >
          {hypothesis}
        </div>
        {hypothesisMeta && (
          <div
            style={{
              marginTop: 10,
              fontFamily: "var(--gh-mono)",
              fontSize: 10.5,
              color: "var(--gh-faint)",
              letterSpacing: "0.06em",
              textTransform: "uppercase",
            }}
          >
            {hypothesisMeta}
          </div>
        )}
      </div>
    </aside>
  );
}

function NavRow({ entry }: { entry: NavEntry }) {
  return (
    <NavLink
      to={entry.to}
      end={entry.to === "/"}
      style={({ isActive }) => ({
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "10px 12px",
        borderLeft: `2px solid ${
          isActive ? "var(--gh-moss)" : "transparent"
        }`,
        borderRadius: "0 4px 4px 0",
        background: isActive ? "var(--gh-canvas)" : "transparent",
        color: isActive ? "var(--gh-ink)" : "var(--gh-muted)",
        fontFamily: "var(--gh-sans)",
        fontSize: 13.5,
        fontWeight: 500,
        textAlign: "left",
        cursor: "pointer",
        transition: "all var(--gh-dur-base) var(--gh-ease)",
      })}
    >
      {({ isActive }) => (
        <>
          <span
            style={{
              fontFamily: "var(--gh-mono)",
              fontSize: 10.5,
              color: isActive ? "var(--gh-moss)" : "var(--gh-faint)",
              width: 22,
              letterSpacing: "0.04em",
            }}
          >
            {entry.num ?? entry.glyph}
          </span>
          <span>{entry.label}</span>
        </>
      )}
    </NavLink>
  );
}

// ---------- Topbar ----------
function Topbar({
  crumbs,
  actions,
}: {
  crumbs: string[];
  actions?: ReactNode;
}) {
  return (
    <header
      style={{
        position: "fixed",
        top: 0,
        left: "var(--gh-sidebar-w)",
        right: 0,
        height: "var(--gh-topbar-h)",
        background: "rgba(244,239,230,0.86)",
        backdropFilter: "blur(14px)",
        WebkitBackdropFilter: "blur(14px)",
        borderBottom: "1px solid var(--gh-line)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 36px",
        zIndex: 20,
      }}
    >
      <nav style={{ display: "flex", alignItems: "center", gap: 10 }}>
        {crumbs.map((c, i) => (
          <span key={i} style={{ display: "inline-flex", gap: 10 }}>
            <span
              className="gh-eyebrow"
              style={{
                color:
                  i === crumbs.length - 1
                    ? "var(--gh-ink)"
                    : "var(--gh-faint)",
              }}
            >
              {c}
            </span>
            {i < crumbs.length - 1 && (
              <span className="gh-eyebrow" style={{ color: "var(--gh-faint)" }}>
                /
              </span>
            )}
          </span>
        ))}
      </nav>
      {actions && (
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          {actions}
        </div>
      )}
    </header>
  );
}

// ---------- Page ----------
export function Page({
  children,
  crumbs,
  actions,
}: {
  children: ReactNode;
  crumbs: string[];
  actions?: ReactNode;
}) {
  return (
    <>
      <Topbar crumbs={crumbs} actions={actions} />
      <main
        className="gh-canvas"
        style={{
          marginLeft: "var(--gh-sidebar-w)",
          padding: "calc(var(--gh-topbar-h) + 40px) 40px 64px",
          minHeight: "100vh",
        }}
      >
        <div
          style={{
            maxWidth: "var(--gh-content-max)",
            margin: "0 auto",
          }}
        >
          {children}
        </div>
      </main>
    </>
  );
}

// ---------- AppShell wrapper ----------
export function AppShell({
  children,
  ownerLabel,
  hypothesis,
  hypothesisMeta,
}: {
  children: ReactNode;
  ownerLabel: string;
  hypothesis: string;
  hypothesisMeta?: string;
}) {
  // touch useLocation just to ensure NavLink rerenders pick up route changes
  useLocation();
  return (
    <>
      <Sidebar
        ownerLabel={ownerLabel}
        hypothesis={hypothesis}
        hypothesisMeta={hypothesisMeta}
      />
      {children}
    </>
  );
}
