import type { CSSProperties, ReactNode } from "react";

// ---------- Eyebrow ----------
export function Eyebrow({
  children,
  style,
}: {
  children: ReactNode;
  style?: CSSProperties;
}) {
  return (
    <div className="gh-eyebrow" style={style}>
      {children}
    </div>
  );
}

// ---------- Chip ----------
type ChipTone = "default" | "positive" | "caution" | "warn" | "neutral";

export function Chip({
  children,
  tone = "default",
  style,
}: {
  children: ReactNode;
  tone?: ChipTone;
  style?: CSSProperties;
}) {
  const toneClass =
    tone === "default" ? "" : `gh-chip-${tone}`;
  return (
    <span className={`gh-chip ${toneClass}`.trim()} style={style}>
      {children}
    </span>
  );
}

// ---------- Btn ----------
type BtnVariant = "default" | "primary" | "ghost";

export function Btn({
  children,
  variant = "default",
  sm = false,
  onClick,
  type = "button",
  style,
}: {
  children: ReactNode;
  variant?: BtnVariant;
  sm?: boolean;
  onClick?: () => void;
  type?: "button" | "submit";
  style?: CSSProperties;
}) {
  const cls = [
    "gh-btn",
    variant === "primary" ? "gh-btn-primary" : "",
    variant === "ghost" ? "gh-btn-ghost" : "",
    sm ? "gh-btn-sm" : "",
  ]
    .filter(Boolean)
    .join(" ");
  return (
    <button type={type} className={cls} onClick={onClick} style={style}>
      {children}
    </button>
  );
}

// ---------- ScoreRail ----------
export function ScoreRail({ value, max = 10 }: { value: number; max?: number }) {
  const segs = Array.from({ length: max }, (_, i) => i < value);
  return (
    <div className="gh-score-rail" aria-label={`Score ${value} of ${max}`}>
      {segs.map((on, i) => (
        <div
          key={i}
          className={`gh-score-seg ${on ? "is-on" : ""}`.trim()}
        />
      ))}
    </div>
  );
}

// ---------- Card ----------
export function Card({
  children,
  style,
  onClick,
}: {
  children: ReactNode;
  style?: CSSProperties;
  onClick?: () => void;
}) {
  return (
    <div
      className="gh-card"
      onClick={onClick}
      style={{ cursor: onClick ? "pointer" : "default", ...style }}
    >
      {children}
    </div>
  );
}

// ---------- PageHead ----------
export function PageHead({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div style={{ marginBottom: 48, maxWidth: 760 }}>
      <Eyebrow>{eyebrow}</Eyebrow>
      <h1
        style={{
          marginTop: 16,
          fontSize: 44,
          letterSpacing: "-0.02em",
          lineHeight: 1.05,
        }}
      >
        {title}
      </h1>
      {subtitle && (
        <p
          style={{
            marginTop: 16,
            fontSize: 17,
            color: "var(--gh-muted)",
            lineHeight: 1.55,
          }}
        >
          {subtitle}
        </p>
      )}
    </div>
  );
}

// ---------- Module (titled section card) ----------
export function Module({
  eyebrow,
  title,
  action,
  children,
  style,
}: {
  eyebrow: string;
  title: string;
  action?: ReactNode;
  children?: ReactNode;
  style?: CSSProperties;
}) {
  return (
    <div className="gh-card" style={style}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: 16,
          marginBottom: 16,
        }}
      >
        <div>
          <Eyebrow>{eyebrow}</Eyebrow>
          <h4
            style={{
              marginTop: 8,
              fontSize: 18,
              fontVariationSettings: "'opsz' 14, 'SOFT' 0, 'wght' 500",
              letterSpacing: "-0.01em",
            }}
          >
            {title}
          </h4>
        </div>
        {action && <div>{action}</div>}
      </div>
      {children}
    </div>
  );
}

// ---------- Stat ----------
export function Stat({
  label,
  value,
  sub,
}: {
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div style={{ flex: 1, minWidth: 0 }}>
      <Eyebrow>{label}</Eyebrow>
      <div
        style={{
          marginTop: 10,
          fontFamily: "var(--gh-serif)",
          fontSize: 32,
          fontVariationSettings: "'opsz' 144, 'SOFT' 50, 'wght' 420",
          color: "var(--gh-ink)",
          letterSpacing: "-0.02em",
          lineHeight: 1,
        }}
      >
        {value}
      </div>
      {sub && (
        <div
          style={{
            marginTop: 8,
            fontSize: 12,
            color: "var(--gh-muted)",
          }}
        >
          {sub}
        </div>
      )}
    </div>
  );
}
