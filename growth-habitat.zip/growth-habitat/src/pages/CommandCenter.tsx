import {
  Btn,
  Card,
  Chip,
  Eyebrow,
  Module,
  PageHead,
  ScoreRail,
  Stat,
} from "../components/Primitives";
import { Page } from "../components/Shell";

// ---------- Hard-coded preview content ----------
// Will be replaced by live data from the storage layer in the next pass.

const HYPOTHESIS =
  "I'm testing whether AI workforce adoption inside governance-aware organizations is where my translator, activator, and structured creativity strengths compound fastest over the next 3 years.";

const STRONGEST_DIRECTION = {
  name: "AI Adoption Consulting",
  averageScore: 8.4,
  description:
    "Combines change, people, governance, and practical AI enablement — the territory where Achim's existing experience meets the strongest market pull.",
  scoreBreakdown: [
    { label: "Strengths fit", value: 9 },
    { label: "Interest", value: 9 },
    { label: "Learning potential", value: 8 },
  ],
};

const BEST_CONVERSATION = {
  person: "Microsoft Partner Conversation",
  org: "Swiss Microsoft Partner",
  role: "Head of Modern Work",
  energyGain: 3,
  insight:
    "The market gap they described — Copilot rolled out without governance-aware adoption — is exactly the work I do.",
  followUp: "Send a short note this week. Reference the governance angle.",
};

const NEXT_STEP = {
  title: "Three short outreach notes to AI adoption leads",
  description:
    "One concrete action this week. Smaller experiments produce faster evidence.",
  due: "Fri, 1 May",
};

const WARNINGS = [
  "Independent Consulting scores high on autonomy but low on access right now — not a near-term direction.",
  "Two recent conversations had high admiration but low market pull — energizing, but no immediate signal.",
];

const PROGRESS_TILES = [
  {
    num: "01",
    to: "/profile",
    title: "Profile",
    sub: "Strengths, working style, non-negotiables",
    meta: "Drafted",
  },
  {
    num: "02",
    to: "/directions",
    title: "Directions",
    sub: "7 directions to compare",
    meta: "5 active · 2 explore",
  },
  {
    num: "03",
    to: "/conversations",
    title: "Conversations",
    sub: "Energy, learning, recognition, market pull",
    meta: "5 logged",
  },
  {
    num: "04",
    to: "/opportunities",
    title: "Opportunities",
    sub: "Fit by problem, people, learning, autonomy",
    meta: "0 logged",
  },
  {
    num: "05",
    to: "/patterns",
    title: "Patterns",
    sub: "What the evidence says · 7-day step",
    meta: "v1 hypothesis",
  },
];

// ---------- Page ----------
export default function CommandCenter() {
  const today = new Date().toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
  });

  return (
    <Page
      crumbs={["Career discovery", "Command Center"]}
      actions={
        <>
          <Btn sm>Add conversation</Btn>
          <Btn sm>Add opportunity</Btn>
          <Btn sm variant="primary">
            Export career brief
          </Btn>
        </>
      }
    >
      <PageHead
        eyebrow={`Command Center · ${today}`}
        title="Find where your abilities compound fastest."
        subtitle="Use conversations, opportunities, and evidence to clarify your next career direction. Six surfaces. One hypothesis at a time."
      />

      {/* Row 1: hypothesis + warnings */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "minmax(0, 2fr) minmax(0, 1fr)",
          gap: 24,
          marginBottom: 32,
        }}
      >
        <Card style={{ padding: 32 }}>
          <Eyebrow>Working hypothesis · v1</Eyebrow>
          <p
            className="gh-quote"
            style={{
              marginTop: 16,
              fontSize: 24,
              lineHeight: 1.35,
              textWrap: "pretty",
            }}
          >
            “{HYPOTHESIS}”
          </p>
          <div
            style={{
              display: "flex",
              gap: 32,
              marginTop: 28,
              paddingTop: 20,
              borderTop: "1px solid var(--gh-line-soft)",
            }}
          >
            <Stat label="Conversations" value="5" sub="last 30d" />
            <Stat label="Active directions" value="5" sub="of 7 tracked" />
            <Stat label="Strongest fit" value="9.0" sub="strengths match" />
            <Stat label="Energy gain" value="+2.4" sub="avg per conversation" />
          </div>
        </Card>

        <Card>
          <Eyebrow>Watch-outs</Eyebrow>
          <ul
            style={{
              listStyle: "none",
              padding: 0,
              margin: "16px 0 0",
              display: "flex",
              flexDirection: "column",
              gap: 14,
            }}
          >
            {WARNINGS.map((w, i) => (
              <li
                key={i}
                style={{
                  display: "flex",
                  gap: 10,
                  fontSize: 13.5,
                  color: "var(--gh-ink-soft)",
                  lineHeight: 1.5,
                }}
              >
                <span
                  aria-hidden
                  style={{
                    flexShrink: 0,
                    marginTop: 6,
                    width: 5,
                    height: 5,
                    background: "var(--gh-warn)",
                    borderRadius: 999,
                  }}
                />
                <span>{w}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      {/* Row 2: three modules */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr",
          gap: 24,
          marginBottom: 32,
        }}
      >
        <Module
          eyebrow="Strongest direction"
          title={STRONGEST_DIRECTION.name}
          action={
            <Chip tone="positive">
              Pursue · {STRONGEST_DIRECTION.averageScore.toFixed(1)}
            </Chip>
          }
        >
          <p
            style={{
              color: "var(--gh-muted)",
              fontSize: 13.5,
              lineHeight: 1.55,
            }}
          >
            {STRONGEST_DIRECTION.description}
          </p>
          <div
            style={{
              marginTop: 18,
              paddingTop: 16,
              borderTop: "1px solid var(--gh-line-soft)",
              display: "grid",
              gap: 10,
            }}
          >
            {STRONGEST_DIRECTION.scoreBreakdown.map((s) => (
              <div
                key={s.label}
                style={{
                  display: "grid",
                  gridTemplateColumns: "120px 1fr 24px",
                  gap: 12,
                  alignItems: "center",
                }}
              >
                <span
                  style={{
                    fontFamily: "var(--gh-mono)",
                    fontSize: 10.5,
                    color: "var(--gh-faint)",
                    textTransform: "uppercase",
                    letterSpacing: "0.06em",
                  }}
                >
                  {s.label}
                </span>
                <ScoreRail value={s.value} />
                <span
                  style={{
                    fontFamily: "var(--gh-mono)",
                    fontSize: 12,
                    color: "var(--gh-ink)",
                    textAlign: "right",
                  }}
                >
                  {s.value}
                </span>
              </div>
            ))}
          </div>
        </Module>

        <Module
          eyebrow="Best recent conversation"
          title={BEST_CONVERSATION.person}
          action={
            <Chip tone="positive">↗ +{BEST_CONVERSATION.energyGain}</Chip>
          }
        >
          <Eyebrow style={{ marginBottom: 12 }}>
            {BEST_CONVERSATION.org} · {BEST_CONVERSATION.role}
          </Eyebrow>
          <p
            className="gh-quote"
            style={{ fontSize: 16, lineHeight: 1.45, textWrap: "pretty" }}
          >
            “{BEST_CONVERSATION.insight}”
          </p>
          <div
            style={{
              marginTop: 16,
              fontSize: 12.5,
              color: "var(--gh-muted)",
              lineHeight: 1.5,
            }}
          >
            {BEST_CONVERSATION.followUp}
          </div>
        </Module>

        <Module
          eyebrow="Next step"
          title={NEXT_STEP.title}
          action={<Chip>Due {NEXT_STEP.due}</Chip>}
        >
          <p
            style={{
              color: "var(--gh-muted)",
              fontSize: 13.5,
              lineHeight: 1.55,
            }}
          >
            {NEXT_STEP.description}
          </p>
          <div style={{ marginTop: 20, display: "flex", gap: 8 }}>
            <Btn variant="primary" sm>
              Mark complete
            </Btn>
            <Btn sm>Reschedule</Btn>
          </div>
        </Module>
      </div>

      {/* Row 3: progress strip */}
      <Module
        eyebrow="Discovery surfaces"
        title="Five sections · evidence over advice"
        action={<Btn sm>Review patterns →</Btn>}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(5, 1fr)",
            gap: 0,
            marginTop: 4,
          }}
        >
          {PROGRESS_TILES.map((m, i) => (
            <a
              key={m.num}
              href={m.to}
              style={{
                padding: "16px 18px",
                borderRight:
                  i < PROGRESS_TILES.length - 1
                    ? "1px solid var(--gh-line-soft)"
                    : "none",
                transition: "background 220ms var(--gh-ease)",
              }}
              onMouseEnter={(e) =>
                ((e.currentTarget as HTMLElement).style.background =
                  "var(--gh-canvas)")
              }
              onMouseLeave={(e) =>
                ((e.currentTarget as HTMLElement).style.background =
                  "transparent")
              }
            >
              <div
                style={{
                  fontFamily: "var(--gh-mono)",
                  fontSize: 11,
                  color: "var(--gh-moss)",
                  letterSpacing: "0.06em",
                }}
              >
                {m.num}
              </div>
              <div
                style={{
                  marginTop: 10,
                  fontFamily: "var(--gh-serif)",
                  fontVariationSettings: "'opsz' 14, 'SOFT' 0, 'wght' 500",
                  fontSize: 16,
                  color: "var(--gh-ink)",
                  letterSpacing: "-0.01em",
                }}
              >
                {m.title}
              </div>
              <div
                style={{
                  marginTop: 6,
                  fontSize: 12.5,
                  color: "var(--gh-muted)",
                  lineHeight: 1.5,
                }}
              >
                {m.sub}
              </div>
              <div
                style={{
                  marginTop: 12,
                  fontFamily: "var(--gh-mono)",
                  fontSize: 10.5,
                  color: "var(--gh-faint)",
                  textTransform: "uppercase",
                  letterSpacing: "0.06em",
                }}
              >
                {m.meta}
              </div>
            </a>
          ))}
        </div>
      </Module>
    </Page>
  );
}
